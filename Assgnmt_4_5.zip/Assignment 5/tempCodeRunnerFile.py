
    date = datetime(2025, 1, 10)